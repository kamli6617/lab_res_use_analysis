<html>
	<head>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	
	<?php include("HomePageGovAgency.php");
	?><br><br><br>
			<div style="align:left-side;hieght:50px;width:100%"></div>
		<form>
		<center>
			<h2> <font color="White">Message To Purchase Department</font></h2>
			<table border=2 cellspacing="20" style=background-color:white>
				<tr>
					<td> Subject:-</td>
					<td> <input typ="text" name="subject"> </td>
				</tr>
				<tr>
					<td> Description:- </td>
					<td> <textarea name="description"> </textarea></td>
				</tr>
				<tr>
					<td colspan="2">
					<center>
					<input type="Submit" name="send" value="Send">
					</center>	
					</td>
				</tr>
			</table>
		</center>	
		</form>
	<body>
</html>