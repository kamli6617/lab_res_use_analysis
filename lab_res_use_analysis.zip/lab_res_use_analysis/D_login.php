<?php
	session_start();
	require("config.php");
	
	$uid=$_POST['userid'];
	$utype=$_POST['usertype'];
	$p=$_POST['pass'];
	
	
	$sql="select * from userdetails where username='$uid' AND typeofuser='$utype' AND psw='$p'";
	$s=mysql_query($sql);
	//while ($row = mysql_fetch_array($sql))
	//{
        if(isset($s) && $utype=="Purchase Department")
		{
			$_SESSION['username']=$uid;
			header("location:HomePagePurchaseDept.php");
		}
		else if(isset($s) && $utype=="Govt Agency")
		{
			$_SESSION['USERNAME']=$uid;
			header("location:HomePageGovAgency.php");
		}
		else
		{
			header("location:login.php?err=1");
			
		}
	
	
?>