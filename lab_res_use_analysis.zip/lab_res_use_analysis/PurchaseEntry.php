<html>
	<head>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<div>	
			<ul>
				<li> <a href="#">Home </a> </li>
				
				<li> <a href="#">Maintenance Entry</a> 
					
				</li>
				<li> <a href="#">Laboratory Log </a>
					
				</li>
				<li> <a href="#">Messages</a> 
				</li>
				<li> <a href="#">Logout </a> </li>
			</ul>
			</div>
			<div style="align:left-side;hieght:50px;width:100%"></div>
			<div style="align:left-side;hieght:500px;width:200px">
			<ul>
				<li> <a href="#">Purchase History </a> </li>
				
				<li> <a href="#">Maintenance History</a> 
					
				</li>
				<li> <a href="#">Lab Log History </a>
					
				</li>
			</ul>
		</div>
		<br><br><br>
		 <form>
		 <center>
		 <h2> <font color="white"> Purchase Entry </font></h2>
			<table border="2" cellspacing="10"style=background-color:white>
				<tr>
					<td> purchase Type:-</td>
					<td> <input type="radio" name="type" value="Hardware"> Hardware
						<input type="radio" name="type" value="Software"> Software
					</td>
				</tr>
				<tr>
					<td> Item Type:-</td>
					<td> <input type="text" name="itemname"></td>
				</tr>
				<tr>
					<td> Software Type:-</td>
					<td> <input type="text" name="softname"></td>
				</tr>
				<tr>
					<td> Item Company Name:-</td>
					<td> <input type="text" name="compname"></td>
				</tr>
				<tr>
					<td> Item Quentity:-</td>
					<td> <input type="text" name="itemname"></td>
				</tr>
				<tr>
					<td> Mfg Date:-</td>
					<td><input type="date" name="mfgdate"></td>
				</tr>
				<tr>
					<td> Expiry Date:-</td>
				<td><input type="date" name="expirydate"></td>	
				</tr>
				<tr>
					<td> Scan Quotation Bill:-</td>
					<td> <input type="file" name="uploadbill"><input type="submit" name="scanbill" value="scanbill"></td>
				</tr>
				<tr>
					<td> Total Bill Amt:-</td>
					<td> <input type="text" name="totalamt"></td>
				</tr>
				<tr>
					<td> Purchase Date:-</td>
					<td><input type="date" name="purdate"></td>
				</tr>
				<tr>
					<td> Item Serial No:-</td>
					<td> <input type="text" name="serialno"></td>
				</tr>
				<tr><td colspan="2" ><center>
					<input type="submit" value="Send to Purchase Department"> 
					 <input type="submit" value="Save as PDF"></center> </td>
				</tr>
			</table>
			</center>
		 </form>
	</body>
</html>