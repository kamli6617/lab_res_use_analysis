<html>
	<head>
		<title>  Laboratory (Hardware/Software) Resource Usage Analysis System
 </title>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
		
	</head>
	<body>
		<br><br><br>
		<div align="center"style="width:100% height:200">
			<h2> <font color="white"><u> Laboratory (Hardware/Software) Resource Usage Analysis System </u></font> </h2>
		</div>
			<br><br><br><center>
		<center>
		<!--===============================================================================================-->	
			<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>	
		<!--===============================================================================================-->
			<!-- <link rel="stylesheet" type="text/css" href="css/util.css"> -->
			<link rel="stylesheet" type="text/css" href="css/main.css">
		<!--===============================================================================================-->
					
				
			<div>
			<form method="POST">
				
				<table border="1" cellspacing="10" align="center" style=background-color:white >
				
						<h3><div style="float:center"><font color="white"> Create New Account </font></div></h3>
					<br>
					<tr>
						<td> User ID:-</td>
						<td> <input type="text" name="user-id"> </td>
					</tr>
					<tr> 
						<td> Password:- </td>	
						<td> <input type="password" name="pass1"> </td>
					</tr>
					<tr> 
						<td> Correct Password:- </td>
						<td> <input type="password" name="pass2"> </td>
					</tr>
					<tr>
						<td> Name:-</td>
						<td> <input type="text" name="name"> </td>
					</tr>
					<tr>
						<td> Address:- </td>
						<td> <textarea name="address"> </textarea></td>
					<tr>
						<td> User Type:-</td>
						<td>
							<select name="user-type">
							<option value="--User Type--"> --Select Type-- </option>
							 <option value="GOVT Agency"> GOVT Agency </option>
							 <option value="Purchase Department"> Purchase Department </option>
						</td>
					</tr>
					<tr>
						<td> Telephone Number 1:- </td>
						<td> <input type="text" name="tno1"> </td>
					</tr>
					<tr>
						<td> Telephone Number 2:- </td>
						<td> <input type="text" name="tno2"></td>
					</tr>
					<tr>
						<td> City </td>
						<td> <input type="text" name="city"> </td>
					</tr>
					<tr>
						<td> District </td>
						<td> <input type="text" name=pin></td>
						
					</tr>
					<tr>
						<td> Pincode </td>
						<td> <input type="text" name="street"></td>
					</tr>
					</table>
					<br>
						<div style="height:50px;width:300">
						<button class="login100-form-btn">
						<a href="">Send Registration Request</a>
						</button>
					    </div>
						
					</br>
			</form>		
			
			
			<!--?php
			if(isset($_POST['insert']))
			{
				$conn = mysql_connect("localhost","root","");
				if($conn)
			{
				echo "MySQL connection OK<br>";
			
				mysql_select_db("Laboratory",$conn);
				$result=mysql_query("SELECT * FROM registration );
			
				$user id= strval($_POST['user-id']);
				$password=strval($_POST['pass1']);
				$correct password=strval($_POST['pass2']);
				$name=strval($_POST['name']);
				$address=strval($_POST['address']);
				$user type=strval($_POST['user-type']);
				$tel no 1= intval($_POST['tno1']);
				$tel no 2=intval($_POST['tno2']);
				$city=strval($_POST['city']);
				$pin=intval($_POST['pin']);
				$street=strval($_POST['street']);
			
			$insert="INSERT INTO `registration` values ($uid','$pass1','$pass2','$name','$address','$user type','$tno1','$tno2','$city','$pin','$street')";
			if(mysql_query($insert,$conn))
			{
				echo "Record Inserted successfully <br>";
			}
			mysql_close($con);
		}
	}
?-->
	</body>
</html>
