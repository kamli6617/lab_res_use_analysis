<html>
	<head>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
	</head>
	<body>
		<?php include("HomePagePurchaseDept.php");
	?>
			<br><br><br>
			<div style="align:left-side;hieght:50px;width:100%"></div>
		
		<form> 
			<center>
			<h2> <font color="White">Analyze Log Details </font></h2>
			<table border="2" cellspacing="20" style=background-color:white>
				<tr><td> Select Department Govt Agent </td>
				<td><select name="SelDepartment">
				<option value="---Select Department---"> ---Select Department--- </option>
					<option value="ABC"> ABC </option>
					<option value="ABC"> DEF </option>
					<option value="ABC"> GHI </option>
				</select></td>
				</tr>
				<tr><td> Select Sub Department Govt Agent </td>
				<td><select name="SelDepartment">
					<option value="---Select Sub Department---"> ---Select Sub Department--- </option>
					<option value="ABC"> DEF </option>
					<option value="ABC"> GHI </option>
				</select></td>
				<tr>
					<td colspan="2"> <center> Generate Log Report </center> </td>
				</tr>
				<tr>
					<td> From Date </td>
					<td> <input type="date" name="fdate"> </td>
				</tr>
				<tr>
					<td> To Date </td>
					<td> <input type="date" name="fdate"> </td>
				</tr>
				<tr>
					<td colspan="2"> <center> <input type="submit" name="view" value="view"> 
 						<input type="submit" name="view" value="Generate PDF"> </center></td>
				</tr>
			</table>
			</center>
		</form>
	</body>
</head>
