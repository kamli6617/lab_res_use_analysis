<html>
	<head>
		<title> Registration From </title>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
	</head>
	
	<body>
	
	<?php include("HomePageGovAgency.php");
	?>
		<br><br><br>
		<table border="2" align="center" cellspacing="10" style=background-color:white>
			<form method="GET" action="">
			
		 <center>
		 <h2> <font color="White"> Lab Usage Entry for school/colleges  </font></h2>
			</td> </tr>
				<tr><td> Department Name</td> <td> <select name="Department">
				<option value="computer">computer</option>
				<option value="civil">civil</option>
				<option value="electronic">electronic</option>
				<option value="IT">It</option>
			</td></tr>
			<tr><td> Lab NO.</td> <td> <select name="Lab">
				<option value="lab1">L01</option>
				<option value="lab2">L02</option>
				<option value="lab3">L03</option>
				<option value="lab4">L04</option>
			</td></tr>
			<tr> <td> Lab co-ordinator Name </td> <td> <input type="text" name="LCN"> </td> </tr>
			<tr> <td> Subject Teacher Name </td> <td> <input type="text" name="TN"> </td> </tr>
			<tr> <td> Subject Name </td> <td> <input type="text" name="SN"> </td> </tr>
			
			<tr> <td> Enter Total SYS Usage </td> <td> <input type="text" name="totsys"> </td> </tr>
			<tr> <td> Usage date </td> <td> <input type="date" name="UD"> </td> </tr>
			<tr> <td> Start time </td> <td> <input type="Time" name="ST"> </td> </tr>
			<tr> <td> End time </td> <td> <input type="Time" name="ET"> </td> </tr>
			<tr><td colspan="2" align=center> <input type="submit" name="save" value="Save">
					 <input type="submit" name="GPDF" value="Generate PDF"> </td></tr>
			</form>
		</table>
		</center>
	</body>
</html>
