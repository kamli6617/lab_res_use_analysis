<html>
	<head>
		<title> Login Form </title>
		<style>
		
			.input
			{
				background-color:#ffffdd;
			}
			body
			{
				background-color:blue;
			}
			h2
			{
				color:white;
			}
		</style>
	</head>
	<body>
	<h1 style="background-color:yellow" align="center"><b><u><i>  Laboratory Resource Usage Analysis </i></u></b><hr/></h1>
		<form method="POST" > </br></br>
			<table border="2" align="center" style=background-color:white>
				<tr> 
					<td colspan = "2" align="center">
						<h1><div style="color:red; float:center"> Login </div>
					</td>
				</tr>
				<tr> 
					<td> User ID:- </td>	
					<td> <input type="text" name="uname"> </td> 
				</tr>
		
			<tr> 
				<td> Password:- </td> 
				<td> <input type="Password" name="pass"> </td>
			</tr>
			
			<tr>
				<td colspan="2" align=center> 
				<input type="submit" name="submit" value="Login"> 
				
				<input type="button" name="clear" value="clear"> </td>
			</tr>			
			</table>
		</form>
		<a href="-----.php"><h2><br><br><br><br><br>Home</h2></a>
		<?php
		
			
			mysql_connect("localhost","root","");
			mysql_select_db("Laboratory");
			
			
			if(isset($_POST['submit']))
			{
				$query="select *from login";
				$result=mysql_query($query);
				while($row=mysql_fetch_assoc($result))
				{
					$uname=$row['username'];
					
					$pass=$row['password'];
				}
				if($_POST['submit']=="Login")
				{
					if($uname==$_POST['uname'] and $pass==$_POST['pass'])
					{
						echo "Log in successfully";
						header("location:upld.php");
					}
					else
					{
						echo "Invalid user name or password...";
					}
				}
				
			}
		?>
	</body>
</html>