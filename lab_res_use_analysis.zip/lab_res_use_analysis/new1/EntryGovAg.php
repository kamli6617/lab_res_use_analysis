<html>
<head>
	<link href="cssstyle.css" rel="stylesheet" type="text/css">
</head>
<body>
	<div>	
			<ul>
				<li> <a href="#">Home </a> </li>
				<li> <a href="purches.html">Purchase Entry </a> </li>
				<li> <a href="Maintenance.html">Maintenance Entry</a> 
					
				</li>
				<li> <a href="#">Laboratory </a>
					<ul>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
					</ul>
				</li>
				<li> <a href="#">MSG from </a> 
					<ul>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
					</ul>
				</li>
				<li> <a href="#">Govt Agency </a>
					<ul>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
						<li> <a href="#"> Enter Name </a> </li>
					</ul>
				</li>
				<li> <a href="#">Logout </a> </li>
			</ul>
			
		</div>
<center>
<form>
<table border="2">
<tr>
		<td>Department name</td>
		<td><select name="Department name" >
			<option value="computer">Computer</option>
			<option value="IT">IT</option>
			<option value="mechanical">Mechanical</option>
			<option value="civil">Civil</option>
			<option value="Electrical">Electrical</option>
		</select>
		</td>
</tr>
<tr>
		<td>System co-ordinator name</td>
		<td><input type="text"name="system"></td>
</tr>
<tr>
		<td>Usage date</td>
		<td><input type="date" name="usage_date"></td>
</tr>
<tr>
		<td>Start time</td>
		<td><input type="time" name="start_time"></td>
</tr>
<tr>
		<td>End time</td>
		<td><input type="time" name="end_time"></td>
</tr>
<tr>

	<td colspan="2" ><center><input type="submit" value="save">
	<input type="reset" value="cancel"></center></td>

</tr>
</table>
</form>
</center>
</body>
</html>
