<html>
	<head>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
	</head>
<body>
	<div>	
			<ul>
				<li> <a href="#">Home </a> </li>
				
				<li> <a href="#">Maintenance Entry</a> 
					
				</li>
				<li> <a href="#">Laboratory Log </a>
					
				</li>
				<li> <a href="#">Messages</a> 
				</li>
				<li> <a href="#">Logout </a> </li>
			</ul>
			</div>
			<div style="align:left-side;hieght:50px;width:100%"></div>
			<div style="align:left-side;hieght:500px;width:200px">
			<ul>
				<li> <a href="#">Purchase History </a> </li>
				
				<li> <a href="#">Maintenance History</a> 
					
				</li>
				<li> <a href="#">Lab Log History </a>
					
				</li>
			</ul>
		</div>
		<br><br><br>
<center>
<form>
		 <center>
		 <h2> <font color="White"> New System Entry </font></h2>
			<table border="2" cellspacing=10 style=background-color:white>
<tr>
		<td>Department name</td>
		<td><select name="Department_name" >
			<option value="IT">IT</option>
			<option value="computer">Computer</option>
			<option value="mechanical">Mechanical</option>
			<option value="civil">Civil</option>
			<option value="Electrical">Electrical</option>
		</select>
		</td>
</tr>


<tr>
	<td>Lab no.</td>
	<td><select name="lab">
		<option value="1" >1</option>
		<option value="2" >2</option>
		</select>
	</td>	
</tr>
<tr>
	<td>Lab co-ordinator name</td>
	<td><input type="text"name="lab_co"></td>
</tr>
<tr>
	<td>Enter new system no.</td>
	<td><input type="text"name="sys_no"></td>
</tr>
<tr>
	<td>System type</td>
	<td><input type="text"name="sys_type"></td>
</tr>		
<tr>
	<td colspan="2" ><center><input type="submit" value="Save">
	<input type="reset" value="Cancel"></center></td>
</tr>
</table>
</form>
</center>
</body>
</html>