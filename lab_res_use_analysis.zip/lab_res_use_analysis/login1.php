<html>
	<head>	
		<title>  Laboratory (Hardware/Software) Resource Usage Analysis System
 </title>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
		
	</head>
	<body>
		<br>
		<div align="center"style="width:100% height:200">
			<h2> <font color="white"> <u>Laboratory (Hardware/Software) Resource Usage Analysis System</u> </font> </h2>
		</div>
			<br><br><br><center>
		<center>
		<!--===============================================================================================-->	
			<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>	
		<!--===============================================================================================-->
			<!-- <link rel="stylesheet" type="text/css" href="css/util.css"> -->
			<link rel="stylesheet" type="text/css" href="css/main.css">
		<!--===============================================================================================-->
					<br/>
					<br/>
					<br/>
					<form class="login100-form validate-form" method="POST" action="loginprocess.php">
					<span class="login100-form-title">
						<font color="white">Member Login</font>
					</span>
					
					<div class="wrap-input100 validate-input" data-validate = "Valid username is required">
						<h3> <font color="white">Enter User ID </font></h3>
						<input class="input100" type="text" name="userid" placeholder="Enter User ID">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
							<tr><?php if(isset($_REQUEST['emlerror'])){echo $_REQUEST['emlerror'];}?></tr>
						</span>
					</div>
					<div class="wrap-input100 validate-input" data-validate = "Valid username is required">
						<h3> <font color="white">Select Type Of User </font></h3>
						<select class="input100" name="userid">
						 <option value="Govt Agency">Govt.Agency</option>
						 <option value="Purchase Department">Purchase Department</option>
						</select>
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-user" aria-hidden="true"></i>
							<tr><?php if(isset($_REQUEST['emlerror'])){echo $_REQUEST['emlerror'];}?></tr>
						</span>
					</div>


					<div class="wrap-input100 validate-input" data-validate = "Password is required">
						<h3><font color="white"> Enter Password </font></h3>
						<input class="input100" type="password" name="password" placeholder="Password">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
							<tr><?php if(isset($_REQUEST['passerror'])){echo $_REQUEST['passerror'];}?></tr>
						</span>
					</div>
					
					<div class="container-login100-form-btn">
						<button class="login100-form-btn">
							<a href="payment.html">Login</a>
						</button>
					</div>
					<br/>
					
					<div align="center">
						
						<a  href="forgotpass.html">
						 <h4> <font color="White" >Forgot User ID/Password?</font><h4>
						</a>
					</div>
					<br/>
					
					<div align="center">
						<a href="regis123.php">
							<h4> <font color="White" >Create your Account </font></h4>
							
						</a>
					</div>
				</form>
			
<!--===============================================================================================-->	
				<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
			<!--===============================================================================================-->
				<script src="vendor/bootstrap/js/popper.js"></script>
				<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
			<!--===============================================================================================-->
				<script src="vendor/select2/select2.min.js"></script>
			<!--===============================================================================================-->
				<script src="vendor/tilt/tilt.jquery.min.js"></script>
					<script >
					$('.js-tilt').tilt({
					scale: 1.1
				})
				</script>
			<!--===============================================================================================-->
				<script src="js/main.js"></script>
</center>
		</center>
			
			
		
	</body>
</html>