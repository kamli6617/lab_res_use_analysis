<html>
	<head>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
	</head>
	<body>
	<?php include("HomePageGovAgency.php");
	
			require('config.php');

	?>
		<br><br><br>
		 <form name="f1" method="POST" action="D_MaintainanceEntry.php" enctype="multipart/form-data">
		 <center>
		 <h2> <font color="White"> Maintenance Entry </font></h2>
			<table border="2" cellspacing=10 style=background-color:white>
				<tr>
					<td> Maintenance Type:-</td>
					<td> <input type="radio" name="type" value="Hardware"> Hardware
						<input type="radio" name="type" value="Software"> Software
					</td>
				</tr>
				<tr>
					<td> Item Type:-</td>
					<td> <input type="text" name="itemname2"></td>
				</tr>
				<tr>
					<td> Software Type:-</td>
					<td> <input type="text" name="softname2"></td>
				</tr>
				<tr>
					<td> Company Name:-</td>
					<td> <input type="text" name="compname"></td>
				</tr>
				<tr>
					<td> Hardware Problem Description:-</td>
					<td> <input type="text" name="descript"></td>
				</tr>
				<tr>
					<td> In Warranty period:-</td>
					<td> <input type="radio" name="warranty" value="Yes"> Yes
						<input type="radio" name="warranty" value="No"> No
					</td>
				</tr>
				
				
				<tr>
					<td> Total Cost(if yes type 0):-</td>
					<td> <input type="text" name="totalcost"></td>
				</tr>
				<tr>
					<td> Repairing Date:-</td>
					<td> <input type="Date" name="repairdate"></td>
				</tr>
				<tr>
					<td> Scan Maintenance Bill:-</td>
					<td> <input type="file" name="Muploadbill"><input type="submit" name="Mscanbill" value="scanbill"></td>
				</tr>
				<tr>
					<td> Item Serial No:-</td>
					<td> <input type="text" name="serialno2"></td>
				</tr>
				
				<tr><td colspan="2" ><center>
					<input type="submit" name="save" value="Send to Purchase Department"> 
					 <input type="submit" name="pdfcopy" value="Save as PDF"></center> </td>
				</tr>
			</table>
			</center>
		 </form>
	</body>
</html>
