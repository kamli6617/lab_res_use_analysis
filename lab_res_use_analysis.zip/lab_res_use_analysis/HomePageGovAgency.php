<?php session_start();?>
<html>
	<head>	
		<title> Laboratory (Hardware/Software) Resource Usage Analysis System </title>
		<link href="cssstyle.css" rel="stylesheet" type="text/css">
		
	</head>
	<body>
		
		<div style="width:100% height:200px">
			<h2> <font color="white"> Laboratory (Hardware/Software) Resource Usage Analysis System </font> </h2>
		</div>

		<div>	
			<ul>
				<li> <a href="HomePageGovAgency.php">Home </a> </li>
				
				<li> <a href="MaintenanceEntry.php">Maintenance Entry</a> 
					
				</li>
				<li> <a href="LabUsageEntry.php">Laboratory Log </a>
					
				</li>
				<li> <a href="MessageToPurchaseDept.php">Messages</a> 
				</li>
				<li><font color="white"><?php if(isset($_SESSION['username'])){echo "Welcome ".$_SESSION['username'];}?></font>
					<input type="submit" name="submit" value="logout">
				</li>
			</ul>
			</div>
			<div style="align:left-side;hieght:50px;width:100%"></div>
			<div style="align:left-side;hieght:500px;width:200px">
			<ul>
				<li> <a href="#">Purchase History </a> </li>
				
				<li> <a href="#">Maintenance History</a> 
					
				</li>
				<li> <a href="#">Lab Log History </a>
					
				</li>
			</ul>
		</div>
		
	</body>
</html>