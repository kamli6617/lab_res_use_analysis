<html> 
<head>
</head>
<body>
<?php
		
		include("HomePageGovAgency.php");
		require("config.php");
?>
<br><br><br><br><br><br>
<center>
<font color="white">
<?php
$mysave=$_POST['save'];
if(isset($mysave))
{
	$t=$_POST['type'];
	$i=$_POST['itemname2'];
	$s=$_POST['softname2'];
	$comp=$_POST['compname'];
	$hpd=$_POST['descript'];
	$w=$_POST['warranty'];
	$t=$_POST['totalcost'];
	$rpdate=$_POST['repairdate'];
	$srno=$_POST['serialno2'];
	$sql="insert into maintenanceentry values('$t','$i','$s','$comp','$hpd','$w','$t','rpdate','$srno')";
	
	mysql_query($sql);
	if(isset($sql))
	{
		

			$target_dir = "uploads/";
			$target_file = $target_dir . basename($_FILES["Muploadbill"]["name"]);
			$uploadOk = 1;
			
				
					if (move_uploaded_file($_FILES["Muploadbill"]["tmp_name"], $target_file)) 
					{
						echo "The file ". basename( $_FILES["Muploadbill"]["name"]). " has been uploaded.";
					} 
					else 
					{
						echo "Sorry, there was an error uploading your file.";
					}
				
				echo" Data Inserted Successfully.....";
	}
	else
	{
				echo" getting error...";
	}

}	
?>
</center>
</font>
</body>
</html>
